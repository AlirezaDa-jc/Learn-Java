package interfaces;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/7/2022
 * Time: 3:00 PM
 */
public interface Work {
    void work();
}
