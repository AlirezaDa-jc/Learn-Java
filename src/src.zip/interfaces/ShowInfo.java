package interfaces;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/7/2022
 * Time: 2:36 PM
 */
//Name Interface = Noun , Adjective
public interface ShowInfo {
    void showInfo();
}
