package casting;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/8/2022
 * Time: 7:30 PM
 */
public class Vehicle {

    public void start() {
        System.out.println("Vehicle Started");
    }
}
