package casting;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/8/2022
 * Time: 7:30 PM
 */
public class Car extends Vehicle {
    public void drive(){
        System.out.println("Driving a Car");
    }

}
