
import packaging.food.*;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/6/2022
 * Time: 3:06 PM
 */
public class PackageTest {
    public static void main(String[] args) {
        Pizza pizza = new Pizza();
        Sushi sushi = new Sushi();
        Hamburger hamburger = new Hamburger();
        Dizi dizi = new Dizi();
    }
}
