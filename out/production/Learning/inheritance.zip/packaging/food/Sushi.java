package packaging.food;

/**
 * Created By Alireza Dolatabadi
 * Date: 8/6/2022
 * Time: 3:08 PM
 */
public class Sushi {
}
